<?php
	$host = "localhost";
	$user = "shell";
	$password = "terps";
	$database = "shellterp";
?>